import { useState } from 'react'

type Section = 'integrations' | 'profile' | 'notifications' | 'jamie' | 'data'

const nav: { group: string; items: { id: Section; label: string; icon: string }[] }[] = [
  { group: 'Workspace', items: [{ id: 'profile', label: 'Profile', icon: '◐' }, { id: 'integrations', label: 'Integrations', icon: '↻' }] },
  { group: 'Preferences', items: [{ id: 'notifications', label: 'Notifications', icon: '◌' }, { id: 'jamie', label: 'Jamie', icon: '✦' }] },
  { group: 'Admin', items: [{ id: 'data', label: 'Data & Privacy', icon: '◎' }] },
]

function Toggle({ on = false }: { on?: boolean }) { return <span className={`relative h-5 w-9 rounded-full transition ${on ? 'bg-[var(--nurture)]' : 'bg-[#e0ddd8]'}`}><span className={`absolute top-[3px] h-3.5 w-3.5 rounded-full bg-white shadow transition ${on ? 'left-[19px]' : 'left-[3px]'}`} /></span> }

function IntegrationCard({ title, desc, connected, color }: { title: string; desc: string; connected?: boolean; color: string }) {
  return <article className={`rounded-[11px] border-[0.5px] bg-white p-5 ${connected ? 'border-[rgba(143,167,144,0.35)]' : 'border-[var(--border)]'}`}><div className="flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-[10px] text-white" style={{ backgroundColor: color }}>{title[0]}</span><div className="min-w-0 flex-1"><p className="text-[13px] font-medium">{title}</p><p className="mt-1 text-[11.5px] leading-relaxed text-[var(--muted)]">{desc}</p></div><button type="button" className={`rounded-[8px] px-3 py-1.5 text-[11.5px] font-medium ${connected ? 'bg-[#f0f6f0] text-[#5a7a60]' : 'bg-[var(--jamie)] text-white'}`}>{connected ? 'Connected' : 'Connect'}</button></div></article>
}

export function SettingsPage() {
  const [section, setSection] = useState<Section>('integrations')

  return (
    <section className="overflow-hidden rounded-xl border-[0.5px] border-[var(--border)] bg-[var(--bg)]">
      <header className="border-b-[0.5px] border-[var(--border)] bg-white px-5 py-4"><h1 className="font-serif text-[22px] font-medium tracking-[-0.4px]">Settings</h1><p className="mt-0.5 text-[11px] text-[var(--muted)]">Manage integrations, preferences, Jamie, and workspace details.</p></header>
      <div className="flex min-h-[620px] overflow-hidden">
        <aside className="hidden w-[190px] shrink-0 overflow-y-auto border-r-[0.5px] border-[var(--border)] bg-white py-4 md:block">
          {nav.map((group) => <div key={group.group}><p className="px-4 pb-1 pt-3 text-[10px] font-medium uppercase tracking-[0.06em] text-[var(--muted)] first:pt-0">{group.group}</p>{group.items.map((item) => <button key={item.id} type="button" className={`flex w-full items-center gap-2 border-l-2 px-4 py-2 text-left text-[12px] transition ${section === item.id ? 'border-l-[var(--jamie)] bg-[#f5f3f0] font-medium text-[var(--jamie)]' : 'border-l-transparent text-[var(--text)] hover:bg-[#f5f3f0]'}`} onClick={() => setSection(item.id)}><span className="w-4 text-center opacity-60">{item.icon}</span>{item.label}</button>)}</div>)}
        </aside>
        <main className="flex-1 overflow-y-auto p-6 md:p-8">
          {section === 'integrations' && <div><h2 className="font-serif text-[21px] font-medium tracking-[-0.3px]">Integrations</h2><p className="mb-5 mt-1 max-w-[560px] text-[12px] leading-relaxed text-[var(--muted)]">Connect the systems that power SpoonFlow’s planning, meeting prep, and follow-up workflows.</p><div className="space-y-3"><IntegrationCard title="Google Calendar" desc="Sync meetings, medical appointments, and prep blocks into your Today and Calendar views." connected color="#6484a1" /><IntegrationCard title="Supabase" desc="Stores contacts, tasks, content items, goals, Jamie conversations, and app settings." connected color="#8fa790" /><IntegrationCard title="Anthropic Claude" desc="Powers Jamie for content support, planning flows, and context-aware guidance." color="#6b2358" /><IntegrationCard title="Fathom" desc="Attach meeting links and transcripts to dossiers and post-meeting workflows." color="#c198ad" /></div></div>}
          {section === 'profile' && <div><h2 className="font-serif text-[21px] font-medium tracking-[-0.3px]">Profile</h2><p className="mb-5 mt-1 max-w-[560px] text-[12px] leading-relaxed text-[var(--muted)]">Basic workspace details used across dashboards and Jamie context.</p><div className="rounded-[11px] border-[0.5px] border-[var(--border)] bg-white p-5"><label className="text-[10.5px] uppercase tracking-[0.05em] text-[var(--muted)]">Name</label><input defaultValue="Meredith" className="mt-2 w-full rounded-[8px] border-[0.5px] border-[var(--border)] px-3 py-2 text-[13px] outline-none" /><label className="mt-4 block text-[10.5px] uppercase tracking-[0.05em] text-[var(--muted)]">Company</label><input defaultValue="Empower Health Strategies" className="mt-2 w-full rounded-[8px] border-[0.5px] border-[var(--border)] px-3 py-2 text-[13px] outline-none" /></div></div>}
          {section === 'notifications' && <div><h2 className="font-serif text-[21px] font-medium tracking-[-0.3px]">Notifications</h2><p className="mb-5 mt-1 max-w-[560px] text-[12px] leading-relaxed text-[var(--muted)]">Choose which prompts and reminders should show up in SpoonFlow.</p><div className="space-y-2">{['Morning planning prompt','Nurture follow-up reminders','Content due soon reminders','Calendar sync alerts'].map((item, index) => <div key={item} className="flex items-center justify-between rounded-[11px] border-[0.5px] border-[var(--border)] bg-white p-4"><span className="text-[13px]">{item}</span><Toggle on={index < 3} /></div>)}</div></div>}
          {section === 'jamie' && <div><h2 className="font-serif text-[21px] font-medium tracking-[-0.3px]">Jamie</h2><p className="mb-5 mt-1 max-w-[560px] text-[12px] leading-relaxed text-[var(--muted)]">Tune Jamie’s support across writing, planning, meetings, and relationship follow-up.</p><div className="rounded-[11px] border-[0.5px] border-[var(--border)] bg-white p-5"><p className="text-[10.5px] uppercase tracking-[0.05em] text-[var(--muted)]">Favorite quick chips</p><div className="mt-3 flex flex-wrap gap-2">{['Sharpen hook','What’s missing','Make concise','More emotional','Stronger ending'].map((chip) => <span key={chip} className="rounded-full bg-[rgba(107,35,88,0.08)] px-3 py-1.5 text-[11px] text-[var(--jamie)]">{chip}</span>)}</div></div></div>}
          {section === 'data' && <div><h2 className="font-serif text-[21px] font-medium tracking-[-0.3px]">Data & Privacy</h2><p className="mb-5 mt-1 max-w-[560px] text-[12px] leading-relaxed text-[var(--muted)]">Export or review the workspace data SpoonFlow uses.</p><div className="grid gap-3 md:grid-cols-2"><div className="rounded-[11px] border-[0.5px] border-[var(--border)] bg-white p-5"><p className="text-[13px] font-medium">Export workspace</p><p className="mt-1 text-[11.5px] text-[var(--muted)]">Download contacts, tasks, content, and goals.</p></div><div className="rounded-[11px] border-[0.5px] border-[var(--border)] bg-white p-5"><p className="text-[13px] font-medium">Review Jamie context</p><p className="mt-1 text-[11.5px] text-[var(--muted)]">See what Jamie can reference while helping you.</p></div></div></div>}
        </main>
      </div>
    </section>
  )
}
